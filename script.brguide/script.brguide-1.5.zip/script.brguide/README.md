BR Guide
======================

![screenshot-01.jpg](https://github.com/olavopeixoto/script.brguide/raw/master/resources/screenshots/screenshot-01.png)

License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html
